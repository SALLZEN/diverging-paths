# Graph 2 and Graph 3 legends

`build-graph-2-3-legends.R` reads the two period-specific GEXF files actually
saved from Gephi for Graph 2 and Graph 3. It extracts the saved node colors and
normalized node sizes, writes the legend data as CSV, and exports standalone
PDF, SVG, and high-resolution PNG legends for placement in Affinity.

Run:

```sh
Rscript build-graph-2-3-legends.R
```

The output files are written to `rendered/`; the extracted values are written
to `data/`.

The GEXF files store plotted node size on a normalized 0--1 scale, not as a
physical print diameter. To change the absolute size of legend circles without
changing their saved relative scaling, edit `MIN_NODE_DIAMETER_MM` and
`MAX_NODE_DIAMETER_MM` near the top of the R script.

The two panels within each graph do not have exactly identical saved node-size
transformations. The legends therefore retain separate 2006--2015 and
2016--2025 rows. Graph 2 has one shared ontology color key, and Graph 3 has one
shared field-orientation colorbar.

`build-graph-c-brokerage-size-legend.R` is the later, dedicated Graph C size
legend builder. It reads the fresh Gephi exports, compares their saved size
mappings at the physical print scale, and uses one shared legend when the
difference is below 0.2 mm. This leaves the older combined Graph 2/Graph 3
legend builder intact.

`build-graph-c-removal-effect-size-legend.R` builds the two-period size key for
the alternative Graph C removal-effect panels. It reads the removal values and
common size inputs from the two GEXFs whose names begin with `removal effect`,
then verifies in the current Gephi project that both workspaces use column `d6`
(`node_size_sqrt_removal_effect_common`), a 5--50 range, and a straight
diagonal interpolator. The plotted sizes are recomputed from those settings;
the legend displays separate period rows because Gephi ranks each workspace
against its own observed input range.
